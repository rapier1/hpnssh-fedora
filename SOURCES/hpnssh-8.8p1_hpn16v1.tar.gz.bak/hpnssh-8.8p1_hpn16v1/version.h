/* $OpenBSD: version.h,v 1.92 2021/09/26 14:01:11 djm Exp $ */

#define SSH_VERSION	"OpenSSH_8.8"

#define SSH_PORTABLE	"p1"
#define SSH_HPN         "-hpn15v5"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE SSH_HPN
