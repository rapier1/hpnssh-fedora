/* $OpenBSD: version.h,v 1.93 2022/02/23 11:07:09 djm Exp $ */

#define SSH_VERSION	"OpenSSH_8.9"

#define SSH_PORTABLE	"p1"
#define SSH_HPN         "-hpn17v0"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE SSH_HPN
